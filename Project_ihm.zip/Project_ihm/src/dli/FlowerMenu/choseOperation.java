package dli.FlowerMenu;


import java.awt.Point;
import java.util.ArrayList;

public class choseOperation {	
	//public ArrayList<Point> pointlist = new ArrayList<Point>();
	public choseOperation() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//l'angle entre le premier point et le dernier point. cette angle est toujour positive entre 0 et 360.
	public int angle(Point startP, Point endP){
		
	        int x= endP.x - startP.x;
	        int y= endP.y - startP.y;
	        double z=Math.sqrt(x*x+y*y);
	        
	        if(x>0 && y>0){
	        	return Math.round((float)(Math.asin(y/z)/Math.PI*180));
	        }
	        else if(x<0 && y>0){
	        	return 180 - Math.round((float)(Math.asin(y/z)/Math.PI*180));
	        }
	        else if(x<0 && y<0){
	        	return 180 - Math.round((float)(Math.asin(y/z)/Math.PI*180));
	        }
	        else return 360 + Math.round((float)(Math.asin(y/z)/Math.PI*180));
		}
	
	public boolean limitePointsX(ArrayList<Point> pointList, int pointX){
		for (int i = 0; i < pointList.size(); i++){
			if ((pointList.get(i).getX() - pointX > 5)||(pointList.get(i).getX() - pointX < -5)){
				return false;
			}
		}
		return true;
	}
	
	public boolean limitePointsY(ArrayList<Point> pointList, int pointY){
		for (int i = 0; i < pointList.size(); i++){
			if ((pointList.get(i).getY() - pointY > 5)||(pointList.get(i).getY() - pointY < -5)){
				return false;
			}
		}
		return true;
	}
	

}

