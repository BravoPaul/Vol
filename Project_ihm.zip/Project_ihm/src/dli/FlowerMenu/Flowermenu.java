
/**
 * @project IHM
 *
 */
package dli.FlowerMenu;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Arc2D.Double;
import java.util.ArrayList;
import java.util.FormatFlagsConversionMismatchException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;






public class Flowermenu extends JFrame implements MouseListener,MouseMotionListener{
	
	
	private String message = "00000";
	private int Xc, Yc;
	private JPanel p;
	private boolean visible = false;
	private Point startPoint = new Point();
	private Point midPoint = new Point(); 
	private Point endPoint = new Point();
	private static buttonItem bItem = new buttonItem();
	private static choseOperation cOperation = new choseOperation();
	private static ArrayList<Point> pList = new ArrayList<Point>();
	private int premierX;
	private int premierY;
	
	
	
	
	private JPanel outline;
	private JPanel fill;
	private String title; // Changes according to the mode
	private String mode;  // Mode of interaction
	private PersistentCanvas canvas; // Stores the created items
	private CanvasItem selection; 	 // Stores the selected item
	
	
	// Listen the mode changes and update the Title
	private ActionListener modeListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			mode = e.getActionCommand();
			updateTitle();
		}
	};
	
	private void updateTitle() {
		setTitle(title + " - " + mode);
	}
	

	
	
	
	
	
	
	

	public Flowermenu(){
		setTitle("Menu Fleur");
        setSize(800,600);
        setLocation(100,100);
        p = new JPanel();
        p.setBackground(new Color(254, 254, 254));
        p.addMouseListener(this);
        p.addMouseMotionListener(this);
        //p.addMouseMotionListener(new GereSourisBouge());
		p.setLayout(null);

		for(int i = 0; i<24; i++){
			p.add(bItem.getButtons(i));
		}

			this.add(p);
		    setVisible(true);
	}
	
	
	
	


		public void paint(Graphics g){
			super.paint(g);
        
			//Dessiner le centre du menu
        
			if (visible){
				
	        	g.setColor(Color.blue);			
	        	g.fillOval(premierX,  premierY , 4, 4 );//dessiner un point;
	        	g.drawOval(premierX-8,  premierY-7, 20, 20 );//dessiner une cercle;
	        	
	        	// la line a droit
				g.drawLine(premierX+12,  premierY+2 , premierX+242, premierY + 2);
				//les deux a droit
				g.drawArc(premierX+12, premierY-118, 180, 120, -80, 72);
				g.drawArc(premierX+12, premierY+1, 180, 120, 10, 72);

				// la line a gauche
				g.drawLine(premierX-7,  premierY+2 , premierX-237, premierY + 2 );
				//les deux a gauch
				g.drawArc(premierX-207, premierY-118, 180, 120, -100, -72);
				g.drawArc(premierX-207, premierY+2, 180, 120, 100, 72);
				
				// la line en bas
				g.drawLine(premierX+2,  premierY-8 , premierX+2, premierY-238 );
				//les deux en bas
				g.drawArc(premierX, premierY+31, 120, 180, 188, 72);
				g.drawArc(premierX-118, premierY+31, 120, 180, -10, -72);
				
				// la line en haut
				g.drawLine(premierX+2,  premierY+13 , premierX+2, premierY+243 );
				//les deux en haut
				g.drawArc(premierX+2, premierY-193, 120, 180, 100, 72);
				g.drawArc(premierX-118, premierY-193, 120, 180, 10, 72);
				
				// la line en bas droit.
				g.drawLine(premierX+10,  premierY+9 , premierX+140, premierY+139 );
				//les deux en bas droit
				g.drawArc(premierX+67, premierY-12, 180, 120, -80, -72);
				g.drawArc(premierX-12, premierY+66, 120, 180, -10, 72);
				
				// la line en haut gauche
				g.drawLine(premierX-5,  premierY-5 , premierX-135, premierY-135 );
				//les deux en haut gauche
				g.drawArc(premierX-235, premierY-95, 180, 120, 30, 72);
				g.drawArc(premierX-95, premierY-232, 120, 180, -120, -72);
				
				// la line en haut droit
				g.drawLine(premierX+10,  premierY-2 , premierX+140, premierY-132 );
				//les deux en haut droit
				g.drawArc(premierX+64, premierY-97, 180, 120, 80, 72);
				g.drawArc(premierX-13, premierY-238, 120, 180, -60, 72);
				
				
				
				// la lien en bas gauche
				g.drawLine(premierX-5,  premierY+10 , premierX-135, premierY+140 );	
				//les deux en bas gauche
				g.drawArc(premierX-100, premierY+63, 120, 180, 120, 72);
				g.drawArc(premierX-239, premierY-14, 180, 120, -30, -72);
				g.setColor(Color.red);
				for (int i = 0; i<pList.size()-1; i++){
					g.drawLine(pList.get(i).x+13, pList.get(i).y+23, pList.get(i+1).x+13, pList.get(i+1).y+23);	
				}
	        }

		}
	
		
		
		public void mousePressed(MouseEvent e) {
			message = "mousePressed";

			if (e.getButton() == MouseEvent.BUTTON1){
				Xc = e.getX();
				Yc = e.getY();
				premierX = Xc +7;
				premierY = Yc + 27;
				visible = true;
				
				//set location pour les bouttons.
				bItem.getButton1().setBounds(premierX-38,premierY-302, 80, 30);
				bItem.getButton9().setBounds(premierX+48,premierY-255, 80, 30);
				bItem.getButton17().setBounds(premierX-126,premierY-255, 80, 30);
				
				bItem.getButton2().setBounds(premierX-38, premierY+208, 80, 30);
				bItem.getButton10().setBounds(premierX-125, premierY+173, 80, 30);
				bItem.getButton18().setBounds(premierX+48, premierY+173, 80, 30);
				
				bItem.getButton3().setBounds(premierX-316, premierY-48, 80, 30);	
				bItem.getButton11().setBounds(premierX-285, premierY-85, 80, 30);
				bItem.getButton19().setBounds(premierX-284, premierY-10, 80, 30);
				
				bItem.getButton4().setBounds(premierX+242, premierY-48, 80,30);
				bItem.getButton12().setBounds(premierX+188, premierY-85, 80,30);
				bItem.getButton20().setBounds(premierX+188, premierY-10, 80,30);
				
				bItem.getButton5().setBounds(premierX+140, premierY-185, 80, 30);
				bItem.getButton13().setBounds(premierX+165, premierY-145, 80, 30);
				bItem.getButton21().setBounds(premierX+102, premierY-220, 80, 30);
				
				bItem.getButton6().setBounds(premierX+140, premierY+80, 80, 30);
				bItem.getButton14().setBounds(premierX+165, premierY+45, 80, 30);
				bItem.getButton22().setBounds(premierX+100, premierY+115, 80, 30);
				
				bItem.getButton7().setBounds(premierX-215, premierY+82, 80, 30);
				bItem.getButton15().setBounds(premierX-245, premierY+50, 80, 30);
				bItem.getButton23().setBounds(premierX-175, premierY+120, 80, 30);
				
				bItem.getButton8().setBounds(premierX-213, premierY-175, 80, 30);
				bItem.getButton16().setBounds(premierX-243, premierY-137, 80, 30);
				bItem.getButton24().setBounds(premierX-173, premierY-215, 80, 30);
				
				bItem.setvisible(1);
				p.validate();
				p.repaint();
				p.updateUI();
				this.validate();
				this.repaint();
	
			}
    }
		
		
		
		public void mouseDragged(MouseEvent e) {
			message = "drag";
			//ajouter tous les points dans la liste.
			if (visible){
				pList.add(new Point(e.getX()-7, e.getY()+8));// apres on a obtebu les points, on doit changer un peu ses positions.
			}
			System.out.println(pList.size());

			this.repaint();
			
			
			if(pList.size() > 20){
				//prend le premier point et le dernier point dans la liste.
				startPoint = pList.get(0);
				endPoint = pList.get(pList.size()-1);
				midPoint = pList.get(pList.size()/2);
				
				int x= endPoint.x - startPoint.x;
		        int y= endPoint.y - startPoint.y;
		        
				double distance = Math.sqrt(x*x+y*y);
				
				int angle = cOperation.angle(startPoint, endPoint);
				int midangle = cOperation.angle(midPoint, endPoint);
				//System.out.println(angle);
				
				//les conditions de choisir les operations.
				
				// en bas droit
				if (angle > 30 && angle < 60 && pList.size() < 80 && distance > 120){
					
					if(bItem.jugeColor() && angle>50 && angle<60 && midangle>angle && distance > 140 && distance < 160){
						bItem.getButton22().setBackground(Color.red);
						//break;
					}
					else if(bItem.jugeColor() && angle > 40 && angle < 50 && distance > 140){
						bItem.getButton6().setBackground(Color.red);
						
					}
					else if (bItem.jugeColor() && angle < 40 && angle > 30 && midangle < angle && distance > 140){
						bItem.getButton14().setBackground(Color.red);
					}
				}
				// en bas
				else if (angle > 60 && angle < 120 && pList.size() < 80 && distance > 120){
					
					if (bItem.jugeColor() && cOperation.limitePointsX(pList, pList.get(0).x) && angle > 85 && angle < 95 && distance > 140 && distance < 170){
						bItem.getButton2().setBackground(Color.red);
					}
					else if (bItem.jugeColor() && angle > 60 && angle < 80 && midangle < angle ){
						bItem.getButton18().setBackground(Color.red);
					}
					else if (bItem.jugeColor() && angle > 100 && angle < 120 && midangle > angle){
						bItem.getButton10().setBackground(Color.red);
					}
				}
				// en bas gauche
				else if (angle > 120 && angle < 150 && pList.size() < 80 && distance > 120){
					
					if(bItem.jugeColor() && angle>140 && angle<150 && midangle > angle && distance > 140 && distance < 160){
						bItem.getButton15().setBackground(Color.red);
						//break;
					}
					
					else if (bItem.jugeColor() && angle < 130 && angle > 120 && midangle < angle && distance > 120){
						bItem.getButton23().setBackground(Color.red);
					}
					else if(bItem.jugeColor() && angle > 130 && angle < 140 && distance > 140){
						bItem.getButton7().setBackground(Color.red);
						
					}
				}
				// a gauche
				else if (angle > 150 && angle < 210 && pList.size() < 80 && distance > 120){
					
					if(bItem.jugeColor() && angle < 185 && angle > 175 && cOperation.limitePointsY(pList, pList.get(0).y) && distance > 210){
						bItem.getButton3().setBackground(Color.red);
						
						
					}
					else if(bItem.jugeColor() && angle > 190 && angle < 205 && midangle > angle){
						bItem.getButton11().setBackground(Color.red);
					}
					else if (bItem.jugeColor() && angle > 155 && angle < 170 && midangle < angle){
						bItem.getButton19().setBackground(Color.red);
					}
				}
				//en haut gauche
				else if (angle < 240 && angle > 210 && pList.size() < 80 && distance > 120){
					
					if(bItem.jugeColor() && angle>230 && angle<240 && midangle > angle && distance > 140 && distance < 160){
						bItem.getButton24().setBackground(Color.red);
						//break;
					}
					
					else if (bItem.jugeColor() && angle < 220 && angle > 210 && midangle < angle && distance > 140){
						bItem.getButton16().setBackground(Color.red);
					}
					else if(bItem.jugeColor() && angle > 220 && angle < 230 && distance > 140){
						bItem.getButton8().setBackground(Color.red);
						
					}
				}
				//en haut
				else if (angle > 240 && angle < 300 && pList.size() < 80 && distance > 120){
					
					if (bItem.jugeColor() && cOperation.limitePointsX(pList, pList.get(0).x) && angle > 265 && angle < 275 && distance > 140 && distance < 170){
						bItem.getButton1().setBackground(Color.red);
					}
					else if (bItem.jugeColor() && angle > 250 && angle < 260 && midangle < angle ){
						bItem.getButton17().setBackground(Color.red);
					}
					else if (bItem.jugeColor() && angle > 280 && angle < 390 && midangle > angle){
						bItem.getButton9().setBackground(Color.red);
					}

				}
				//en haut droit
				else if (angle > 300 && angle < 330 && pList.size() < 80 && distance > 120){
					
					if(bItem.jugeColor() && angle>320 && angle<330 && midangle > angle && distance > 140 && distance < 160){
						bItem.getButton13().setBackground(Color.red);
					}
					
					else if (bItem.jugeColor() && angle < 310 && angle > 300 && midangle < angle && distance > 140){
						bItem.getButton21().setBackground(Color.red);
					}
					else if(bItem.jugeColor() && angle > 310 && angle < 320 && distance > 150){
						bItem.getButton5().setBackground(Color.red);
						
					}
				}
				//a droit
				else if ( ((angle > 330 && angle <= 360)||(angle >= 0 && angle < 30)) && pList.size() < 80 && distance > 120){
					
					if( (bItem.jugeColor() && angle < 5 || angle > 355) && cOperation.limitePointsY(pList, pList.get(0).y) && distance > 160 && distance < 170){
						bItem.getButton4().setBackground(Color.red);
						try {
							Thread.sleep(500);
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.exit(0);
					}
					else if(bItem.jugeColor() && angle > 10 && angle < 20 && midangle > angle){
						bItem.getButton20().setBackground(Color.red);
					}
					else if (bItem.jugeColor() && angle > 345 && angle < 355 && midangle < angle){
						bItem.getButton12().setBackground(Color.red);
					}
				}				
			}
		}
		
		public void mouseReleased(MouseEvent e) {
			message = "mouseReleased";
			try {
				Thread.sleep(300);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			bItem.setvisible(0);
			pList.clear();
			bItem.initColor();
			
			if (e.getButton() == MouseEvent.BUTTON1){
				visible = false;	
				repaint();
			}
		}
	
		public void mouseClicked(MouseEvent e) {
			message = "mouseClicked";
	
		}

		public void mouseEntered(MouseEvent e) {
			message = "mouseEntered";
		}

	    public void mouseExited(MouseEvent e) {
	        message = "mouseExited";
	    }
			

		@Override
		public void mouseMoved(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		
		public static void main(String[] args){
			Flowermenu fl = new Flowermenu();
			//fl.changeButtonColor(pList);
		}

}
