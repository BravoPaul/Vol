
/**
 * @project IHM
 *
 */
package dli.FlowerMenu;

import java.awt.Button;
import java.awt.Color;


public class buttonItem {

	private Button button1;
	private Button button2;
	private Button button3;
	private Button button4;
	private Button button5;
	private Button button6;
	private Button button7;
	private Button button8;
	private Button button9;
	private Button button10;
	private Button button11;
	private Button button12;
	private Button button13;
	private Button button14;
	private Button button15;
	private Button button16;
	private Button button17;
	private Button button18;
	private Button button19;
	private Button button20;
	private Button button21;
	private Button button22;
	private Button button23;
	private Button button24;

	private Button[] buttonList = new Button[24];
	
	public buttonItem() {
		initButton();
		//initColor();
		// TODO Auto-generated constructor stub
	}
	
	//setvisble pour les buttons.
	public void setvisible(int visible){
		if(visible == 1){
			for(int i = 0; i < buttonList.length; i++){
				buttonList[i].setVisible(true);
			}
		}
		else if(visible == 0){
			for(int i = 0; i < buttonList.length; i++){
				buttonList[i].setVisible(false);
			}
		}
	}
	
	
	public Button getButtons(int numButton){
		return buttonList[numButton];
		
	}
	
	public boolean jugeColor(){
		for (int i = 0; i < buttonList.length; i++){
			if (buttonList[i].getBackground() == Color.red){
				return false;
			}
		}
		return true;
	}
	
	public void initColor(){
		for(int i = 0; i < buttonList.length; i++){
			buttonList[i].setBackground(Color.gray);
		} 
	}
	
	public void initButton() {
		button1 = new Button();
		buttonList[0] = button1;
		button1.setLabel("choix1");
		button1.setBackground(Color.gray);
		button1.setVisible(true);

		button2 = new Button();
		buttonList[1] = button2;
		button2.setLabel("choix2");
		button2.setBackground(Color.gray);
		button2.setVisible(false);

		button3 = new Button();
		buttonList[2] = button3;
		button3.setLabel("choix3");
		button3.setBackground(Color.gray);
		button3.setVisible(false);

		button4 = new Button();
		buttonList[3] = button4;
		button4.setLabel("Exit");
		button4.setBackground(Color.gray);
		button4.setVisible(false);

		button5 = new Button();
		buttonList[4] = button5;
		button5.setLabel("choix5");
		button5.setBackground(Color.gray);
		button5.setVisible(false);

		button6 = new Button();
		buttonList[5] = button6;
		button6.setLabel("choix6");
		button6.setBackground(Color.gray);
		button6.setVisible(false);

		button7 = new Button();
		buttonList[6] = button7;
		button7.setLabel("choix7");
		button7.setBackground(Color.gray);
		button7.setVisible(false);

		button8 = new Button();
		buttonList[7] = button8;
		button8.setLabel("choix8");
		button8.setBackground(Color.gray);
		button8.setVisible(false);

		button9 = new Button();
		buttonList[8] = button9;
		button9.setLabel("choix9");
		button9.setBackground(Color.gray);
		button9.setVisible(false);

		button10 = new Button();
		buttonList[9] = button10;
		button10.setLabel("choix10");
		button10.setBackground(Color.gray);
		button10.setVisible(false);

		button11 = new Button();
		buttonList[10] = button11;
		button11.setLabel("choix11");
		button11.setBackground(Color.gray);
		button11.setVisible(false);

		button12 = new Button();
		buttonList[11] = button12;
		button12.setLabel("choix12");
		button12.setBackground(Color.gray);
		button12.setVisible(false);

		button13 = new Button();
		buttonList[12] = button13;
		button13.setLabel("choix13");
		button13.setBackground(Color.gray);
		button13.setVisible(false);

		button14 = new Button();
		buttonList[13] = button14;
		button14.setLabel("choix14");
		button14.setBackground(Color.gray);
		button14.setVisible(false);

		button15 = new Button();
		buttonList[14] = button15;
		button15.setLabel("choix15");
		button15.setBackground(Color.gray);
		button15.setVisible(false);

		button16 = new Button();
		buttonList[15] = button16;
		button16.setLabel("choix16");
		button16.setBackground(Color.gray);
		button16.setVisible(false);

		button17 = new Button();
		buttonList[16] = button17;
		button17.setLabel("choix17");
		button17.setBackground(Color.gray);
		button17.setVisible(false);

		button18 = new Button();
		buttonList[17] = button18;
		button18.setLabel("choix18");
		button18.setBackground(Color.gray);
		button18.setVisible(false);

		button19 = new Button();
		buttonList[18] = button19;
		button19.setLabel("choix19");
		button19.setBackground(Color.gray);
		button19.setVisible(false);

		button20 = new Button();
		buttonList[19] = button20;
		button20.setLabel("choix20");
		button20.setBackground(Color.gray);
		button20.setVisible(false);

		button21 = new Button();
		buttonList[20] = button21;
		button21.setLabel("choix21");
		button21.setBackground(Color.gray);
		button21.setVisible(false);

		button22 = new Button();
		buttonList[21] = button22;
		button22.setLabel("choix22");
		button22.setBackground(Color.gray);
		button22.setVisible(false);

		button23 = new Button();
		buttonList[22] = button23;
		button23.setLabel("choix23");
		button23.setBackground(Color.gray);
		button23.setVisible(false);

		button24 = new Button();
		buttonList[23] = button24;
		button24.setLabel("choix24");
		button24.setBackground(Color.gray);
		button24.setVisible(false);
	}

	public Button getButton1() {
		return button1;
	}

	public void setButton1(Button button1) {
		this.button1 = button1;
	}

	public Button getButton2() {
		return button2;
	}

	public void setButton2(Button button2) {
		this.button2 = button2;
	}

	public Button getButton3() {
		return button3;
	}

	public void setButton3(Button button3) {
		this.button3 = button3;
	}

	public Button getButton4() {
		return button4;
	}

	public void setButton4(Button button4) {
		this.button4 = button4;
	}

	public Button getButton5() {
		return button5;
	}

	public void setButton5(Button button5) {
		this.button5 = button5;
	}

	public Button getButton6() {
		return button6;
	}

	public void setButton6(Button button6) {
		this.button6 = button6;
	}

	public Button getButton7() {
		return button7;
	}

	public void setButton7(Button button7) {
		this.button7 = button7;
	}

	public Button getButton8() {
		return button8;
	}

	public void setButton8(Button button8) {
		this.button8 = button8;
	}

	public Button getButton9() {
		return button9;
	}

	public void setButton9(Button button9) {
		this.button9 = button9;
	}

	public Button getButton10() {
		return button10;
	}

	public void setButton10(Button button10) {
		this.button10 = button10;
	}

	public Button getButton11() {
		return button11;
	}

	public void setButton11(Button button11) {
		this.button11 = button11;
	}

	public Button getButton12() {
		return button12;
	}

	public void setButton12(Button button12) {
		this.button12 = button12;
	}

	public Button getButton13() {
		return button13;
	}

	public void setButton13(Button button13) {
		this.button13 = button13;
	}

	public Button getButton14() {
		return button14;
	}

	public void setButton14(Button button14) {
		this.button14 = button14;
	}

	public Button getButton15() {
		return button15;
	}

	public void setButton15(Button button15) {
		this.button15 = button15;
	}

	public Button getButton16() {
		return button16;
	}

	public void setButton16(Button button16) {
		this.button16 = button16;
	}

	public Button getButton17() {
		return button17;
	}

	public void setButton17(Button button17) {
		this.button17 = button17;
	}

	public Button getButton18() {
		return button18;
	}

	public void setButton18(Button button18) {
		this.button18 = button18;
	}

	public Button getButton19() {
		return button19;
	}

	public void setButton19(Button button19) {
		this.button19 = button19;
	}

	public Button getButton20() {
		return button20;
	}

	public void setButton20(Button button20) {
		this.button20 = button20;
	}

	public Button getButton21() {
		return button21;
	}

	public void setButton21(Button button21) {
		this.button21 = button21;
	}

	public Button getButton22() {
		return button22;
	}

	public void setButton22(Button button22) {
		this.button22 = button22;
	}

	public Button getButton23() {
		return button23;
	}

	public void setButton23(Button button23) {
		this.button23 = button23;
	}

	public Button getButton24() {
		return button24;
	}

	public void setButton24(Button button24) {
		this.button24 = button24;
	}

}
