package data;

import java.util.ArrayList;

public class Country {
	
	private String name;
   
	private	ArrayList<City> cities;
	private ArrayList<AirLine> airlines;
	
	
	
	 public Country(String name) {
			super();
			cities = new ArrayList<City>();
			airlines = new ArrayList<AirLine>();
			this.name = name;
	}

	 	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<City> getCities() {
		return cities;
	}

	public void setCities(City city) {
		this.cities.add(city);
	}

	public ArrayList<AirLine> getAirlines() {
		return airlines;
	}

	public void setAirlines(AirLine airlines) {
		this.airlines.add(airlines);
	}
	
	public City getcity(String city) {
		for (int j = 0; j < this.getCities().size(); j++) {
			if (this.getCities().get(j).getName().equals(city)) {
				return this.getCities().get(j);
			}
		}
		return null;
	}


	@Override
	public String toString() {
		return "Country [name=" + name + ", cities=" + cities + ", airlines="
				+ airlines + "]";
	}

	public void setCities(ArrayList<City> cities) {
		this.cities = cities;
	}



	public void setAirlines(ArrayList<AirLine> airlines) {
		this.airlines = airlines;
	}


	public ArrayList<Route> getRoutes() {
		
		ArrayList<Route> routes = new ArrayList<Route>();
		
		for (int k = 0; k < this.getCities().size(); k++) {
			
			City city = this.getCities().get(k);
			
			for (int i = 0; i < city.getAirports().size(); i++) {
				Airport airport = city.getAirports().get(i);
				for (int j = 0; j < Test.routes.size(); j++) {
					Route route = Test.routes.get(j);
					if (route.getSairportName().equals(airport.getIata())) {
						routes.add(route);
					
					}
				}	
			}		
		}
		return routes;
	}
	
	public ArrayList<Route> getRoutes(Country country) {
		
		ArrayList<Route> routes = new ArrayList<Route>();
		
		for (int j = 0; j < Test.routes.size(); j++) {
			Route route = Test.routes.get(j);
			for (int k = 0; k < this.getCities().size(); k++) {
				City city = this.getCities().get(k);
				for (int i = 0; i < city.getAirports().size(); i++) {
					Airport airport = city.getAirports().get(i);
					for (int l = 0; l < country.getCities().size(); l++) {
						City city2 = country.getCities().get(l);
						for (int m = 0; m < city2.getAirports().size(); m++) {
							Airport airport2 = city2.getAirports().get(m);
							if (route.getSairportName().equals(airport.getIata())&&route.getDairportName().equals(airport2.getIata())) {
								routes.add(route);
							}
						}
					}					
				}
			}	
		}		
		
		return routes;
	}
	
}
