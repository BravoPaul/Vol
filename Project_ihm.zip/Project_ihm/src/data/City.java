package data;

import java.util.ArrayList;

public class City {
	
	private ArrayList<Airport> airports;
	private String country;
	private String name;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<Airport> getAirports() {
		return airports;
	}
	public City(String country, String name) {
		super();
		airports = new ArrayList<Airport>();
		this.country = country;
		this.name = name;
	}
	public void setAirports(Airport airport) {
		airports.add(airport);
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	public ArrayList<Route> getRoute() {
		
		ArrayList<Route> routes = new ArrayList<Route>();
		
		for (int j = 0; j < Test.routes.size(); j++) {
			Route route = Test.routes.get(j);
			for (int i = 0; i < this.airports.size(); i++) {
				Airport airport = this.airports.get(i);
				if (route.getSairportName().equals(airport.getIata())) {
					routes.add(route);
				}
			}
		}
		return routes;
	}
	
	public ArrayList<Route> getRoute(City city) {
		
		ArrayList<Route> routes = new ArrayList<Route>();
		
		for (int j = 0; j < Test.routes.size(); j++) {
			Route route = Test.routes.get(j);
				for (int i = 0; i < this.airports.size(); i++) {
					Airport airport = this.airports.get(i);
					for (int k = 0; k < city.getAirports().size(); k++) {
					Airport dairport = city.getAirports().get(k);
					if (route.getSairportName().equals(airport.getIata())&&route.getDairportName().equals(dairport.getIata())) {
						routes.add(route);
					}
				}			
			}
		}
		return routes;
	}
	
	
}
